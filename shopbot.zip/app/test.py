"""def horse(hod1, hod2):
    x1, y1 = ord(hod1[0]), int(hod1[1])
    x2, y2 = ord(hod2[0]), int(hod2[1])
    return True if (x1 - x2) ** 2 + (y1 - y2) ** 2 == 5 else False

horse('d4', 'b3')"""

import math

"""def print_average(arr):
    f_sum = sum(arr)
    average = f_sum / len(arr) if len(arr) > 0 else 0
    print(average if len(arr) > 0 else 0)
    
print_average([])"""

"""def print_statistics(arr):
    arr.sort()
    
    n = len(arr)
    f_sum = sum(arr)
    average = f_sum / len(arr) if len(arr) > 0 else 0
    max_num = max(arr) if n > 0 else 0
    min_num = min(arr) if n > 0 else 0
    
    if len(arr) % 2 == 0 and n > 0: 
        median = arr[len(arr) // 2]
    elif n > 1 and n % 2 != 0:
        median = arr[(arr[n // 2 - 1] + arr[n // 2]) // 2]
    elif n == 1 and n % 2 != 0:
        median = arr[0]
    else:
        median = 0
        
    n = int(n)
    average = float(average)
    max_num = float(max_num)
    min_num = float(min_num)
    median = float(median)
    
    to_print = f'{n}\n{average}\n{max_num}\n{min_num}\n{median}'
    print(to_print)

print_statistics([22])"""

"""def take_large_banknotes(banknotes):
    n = []
    for i in banknotes:
        if i > 10:
            n.append(i)
    return n

print(*take_large_banknotes([1, 5, 500, 0.5, 2, 0.1, 10, 100, 100, 1000, 50]))"""

"""def print_document(pages):
    for i in range(len(pages)):
        if pages[i].startswith('Секретно'):
            stop = pages[i]
            index_of_stop = pages.index(stop)
            break
        else:
            index_of_stop = None
            
    print(index_of_stop)
    
    text_to_print = pages[:index_of_stop]
    print(text_to_print)
    
    for i in text_to_print:
        print(i)
    
    pages_len = len(pages)
    text_to_print_len = len(text_to_print)
    
    print('Напечатано без купюр' if pages_len == text_to_print_len else 'Дальнейшие материалы засекречены')
    
    
print_document(['Привет мир', "Тебе это можно видеть", "Дальше уже лисать нельзя", "Не листай я сказал!!!"])"""

"""months = {
    'ru': {
        1: 'январь',
        2: 'февраль',
        3: 'март',
        4: 'апрель',
        5: 'май',
        6: 'июнь',
        7: 'июль',
        8: 'август',
        9: 'сентябрь',
        10: 'октябрь',
        11: 'ноябрь',
        12: 'декабрь'
    },
    'en': {
        1: 'January',
        2: 'Februrary',
        3: 'March',
        4: 'April',
        5: 'May',
        6: 'June',
        7: 'July',
        8: 'August',
        9: 'September',
        10: 'October',
        11: 'November',
        12: 'December',
    }
}


def month_name(month, lang):
    print(months[lang][month])

month_name(3, 'en')"""

import tracemalloc

tracemalloc.start()

morse = {
    'a': '.-',    'b': '-...',  'c': '-.-.',  'd': '-..',   'e': '.',
    'f': '..-.',  'g': '--.',   'h': '....',  'i': '..',    'j': '.---',
    'k': '-.-',   'l': '.-..',  'm': '--',    'n': '-.',    'o': '---',
    'p': '.--.',  'q': '--.-',  'r': '.-.',   's': '...',   't': '-',
    'u': '..-',   'v': '...-',  'w': '.--',   'x': '-..-',  'y': '-.--',
    'z': '--..'
}

text = input().lower()
words = text.split()

for word in words:
    encoded = []
    for ch in word:
        encoded.append(morse[ch])
    print(' '.join(encoded))

current, peak = tracemalloc.get_traced_memory()

print(f'Current is: {current / 10 ** 6}MB. Peak is: {peak / 10 ** 6}MB')