from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command, CommandStart, StateFilter
from aiogram.fsm.context import FSMContext

from app.database.requests import set_user, update_user, get_card, add_to_cart, get_cart

import app.keyboards as kb


client = Router()


@client.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    is_user = await set_user(message.from_user.id)
    await message.reply('Hello')
    
    if not is_user:
        await message.answer('Добро пожаловать!\nПройдите процесс регистрации...\n\nВведите ваше имя',
                             reply_markup=await kb.clients_name(message.from_user.first_name))
        await state.set_state('reg_name')
    else:
        await message.answer('Добро пожаловать в онлайн магазин!\n\nИспользуя кнопки ниже, ознакомтесь с ассортиментом',
                             reply_markup=kb.menu)
        

@client.message(StateFilter('reg_name'))
async def reg_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.capitalize())
    await message.answer('Введите номер телефона, или поделитесь с помощью кнопки ниже', reply_markup=kb.phone_number)
    await state.set_state('reg_number')


@client.message(F.contact, StateFilter('reg_number'))
async def get_phone_number(message: Message, state: FSMContext):
    await state.update_data(phone_num=message.contact.phone_number)
    data = await state.get_data()
    await message.answer(f'Регистрация прошла успешно!\nИмя: {data["name"]}\nНомер телефона: {data["phone_num"]}',
                         reply_markup=kb.menu)
    await update_user(tg_id=message.from_user.id, name=data['name'], phone_number=data['phone_num'])
    await state.clear()
    


@client.message(StateFilter('reg_number'))
async def get_phone_number(message: Message, state: FSMContext):
    await state.update_data(phone_num=message.text)
    data = await state.get_data()
    await message.answer(f'Регистрация прошла успешно!\nИмя: {data["name"]}\nНомер телефона: {data["phone_num"]}',
                         reply_markup=kb.menu)
    await update_user(tg_id=message.from_user.id, name=data['name'], phone_number=data['phone_num'])
    await state.clear()


@client.message(F.text == 'Каталог')
async def catalog(message: Message):
    await message.answer('Выберите категорию товара', reply_markup=await kb.get_categories_kb())


@client.message(F.photo)
async def get_photo_id(message: Message):
    await message.answer(message.photo[-1].file_id)

@client.callback_query(F.data.startswith('category_'))
async def categories(callback: CallbackQuery):
    await callback.answer()
    category_id = callback.data.split('_')[1]
    await callback.message.edit_caption('Выберите товар', reply_markup=await kb.get_category_cards(category_id))
    
    
@client.callback_query(F.data.startswith('card_'))
async def get_card_info(callback: CallbackQuery, state: FSMContext):
    await callback.answer()
    item_id = callback.data.split('_')[1]
    card = await get_card(card_id=item_id)
    text = f'{card.name}\n\n{card.description}\n\n${card.price}'
    await callback.message.delete()
    await state.update_data(card_id=item_id)
    await callback.message.answer_photo(photo=card.image,
                                        caption=text,
                                        reply_markup=await kb.back_to_categories(card.category_id, item_id))
    await state.set_state('card_id')
    

@client.callback_query(F.data == 'add_to_cart', StateFilter('card_id'))
async def add_to_cartt(callback: CallbackQuery, state: FSMContext):
    await callback.answer()
    data = await state.get_data()
    card = await get_card(card_id=data['card_id'])
    cart = await add_to_cart(user_id=callback.from_user.id, card_name=card.name, card_price=card.price)
    await callback.message.answer("Товар добавлен в корзину")
    await state.clear()


@client.message(F.text == 'Корзина')
async def cart(message: Message):
    cart = await get_cart(user_id=message.from_user.id)
    text = 'Корзина:\n'
    if  cart == None:
        await message.answer("Ваша корзина пуста")
    else:
        for _ in cart:
            text += f'\n{cart.item_name} - ${cart.item_price}'
        await message.answer(text)