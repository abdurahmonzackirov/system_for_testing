from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

from app.database.requests import get_categories, get_cards_by_category, get_card


menu = ReplyKeyboardMarkup(keyboard=[
    [KeyboardButton(text='Каталог')],
    [KeyboardButton(text='Контакты')],
    [KeyboardButton(text='Корзина')]
],
                           resize_keyboard=True)


async def clients_name(name):
    return ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text=name)]],
                               resize_keyboard=True)
    
phone_number = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text='Поделиться контактом',
                                                             request_contact=True)]],
                                   resize_keyboard=True)


async def get_categories_kb():
    keyboard = InlineKeyboardBuilder()
    categories = await get_categories()
    for category in categories:
        keyboard.add(InlineKeyboardButton(text=category.name,
                                          callback_data=f'category_{category.id}'))
    return keyboard.adjust(2).as_markup()


async def get_category_cards(category_id):
    keyboard = InlineKeyboardBuilder()
    cards = await get_cards_by_category(card_category_id=category_id)
    for card in cards:
        keyboard.row(InlineKeyboardButton(text=card.name,
                                          callback_data=f'card_{card.id}'))
    keyboard.row(InlineKeyboardButton(text='Назад',
                                      callback_data='categories'))
    return keyboard.as_markup()


async def back_to_categories(category_id, card_id):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Купить', callback_data=f'buy_{card_id}')],
        [InlineKeyboardButton(text='Назад', callback_data=f'category_{category_id}')],
        [InlineKeyboardButton(text='Добавить в корзину', callback_data='add_to_cart')]
    ])
    
    
