from app.database.models import async_session
from app.database.models import User, Category, Card, Cart
from sqlalchemy import select, update, insert, delete

def connection(func):
    async def inner(*args, **kwargs):
        async with async_session() as session:
            return await func(session, *args, **kwargs)
    return inner


@connection
async def set_user(session, tg_id):
    user = await session.scalar(select(User).where(User.tg_id == tg_id))
    
    if not user:
        session.add(User(tg_id=tg_id))
        await session.commit()
        return False
    return True if user.name else False


@connection
async def update_user(session, tg_id, name, phone_number):
    await session.execute(update(User).where(User.tg_id == tg_id).values(name=name,
                                                                    phone_number=phone_number))
    await session.commit()
    
    
@connection
async def get_categories(session):
    return await session.scalars(select(Category))


@connection
async def get_cards_by_category(session, card_category_id):
    return await session.scalars(select(Card).where(Card.category_id == card_category_id))


@connection
async def get_card(session, card_id):
    return await session.scalar(select(Card).where(Card.id == card_id))


@connection
async def add_to_cart(session, user_id, card_name, card_price):
    await session.execute(insert(Cart).where(Cart.user_id == user_id).values(item_name=card_name, item_price=card_price))
    await session.commit()
    

@connection
async def get_cart(session, user_id):
    return await session.scalar(select(Cart).where(Cart.user_id == user_id))