from sqlalchemy import ForeignKey, BigInteger, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncAttrs


engine = create_async_engine(url='sqlite+aiosqlite:///shopbot.db')
async_session = async_sessionmaker(engine)


class Base(DeclarativeBase, AsyncAttrs):
    pass

class User(Base):
    __tablename__ = 'users'
    
    id: Mapped[int] = mapped_column(primary_key=True)
    tg_id = mapped_column(BigInteger)
    name: Mapped[str] = mapped_column(String(25), nullable=True)
    phone_number: Mapped[str] = mapped_column(String(25), nullable=True)
    
class Category(Base):
    __tablename__ = 'categories'
    
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(25))
    
class Card(Base):
    __tablename__ = 'cards'
    
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))
    description: Mapped[str] = mapped_column(String(256))
    category_id: Mapped[int] = mapped_column(ForeignKey('categories.id'))
    price: Mapped[int]
    image: Mapped[str] = mapped_column(String(256))

class Cart(Base):
    __tablename__ = 'carts'
    
    id: Mapped[int] = mapped_column(primary_key=True)
    item_name: Mapped[str] = mapped_column(ForeignKey('cards.name'), nullable=True)
    item_price: Mapped[int] = mapped_column(ForeignKey('cards.price'), nullable=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.tg_id'))
    

async def init_models():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)